(function () {
  if (typeof Hanoi === "undefined") {
    window.Hanoi = {};
  }

  var View = Hanoi.View = function (game, $el) {
    this.game = game;
    this.$el = $el;
  };

  View.prototype.bindEvents = function () {
    var game = this.game
    var view = this
    var moves = []

    this.$el.on("click", "ul", function (event) {
      var $ul = $(event.currentTarget);
      moves.push($ul);
      if (moves.length === 2) {
        view.moveDisk(moves);
        moves = [];
      }
    })

  };

  View.prototype.moveDisk = function (moves) {
    var startTower = moves[0].index();
    var endTower = moves[1].index();

    this.game.move(startTower, endTower);
    this.render();
  };

  View.prototype.setupTowers = function () {

    for (var i = 0; i < 3; i++) {
      var $tower = $('<ul></<ul>');
      $tower.addClass('group');

        for (var j = 0; j < 3; j++) {
          var $disk = $('<li></li>');
          $tower.append($disk);
        }

      this.$el.append($tower);
    }

    this.render();

  };

  View.prototype.render = function () {
    var $towers = $("ul");


    for (var i = 0; i < 3; i++) {
      var $lis = $towers.eq(i).children();

      for (var j = 0; j < 3; j++) {
          var $disk = $lis.eq(j);
        if (this.game.towers[i][j] === undefined) {
          $disk.removeClass();

          $disk.addClass("blank");
        } else {

          $disk.removeClass();

          // $lis[j] => give this class number of value
          var diskVal = "disk" + this.game.towers[i][j];
          $disk.addClass(diskVal);

        }


      }
    }
  };


})();