(function () {
  if (typeof TTT === "undefined") {
    window.TTT = {};
  }

  var View = TTT.View = function (game, $el) {
    this.game = game
  };

  View.prototype.bindEvents = function () {
    var view = this;
    $("ul").on("click", "li", function(event){
      var $li = $(event.currentTarget);
      view.makeMove($li);
    })
  };

  View.prototype.makeMove = function ($square) {
    var $index = $square.index();
    var move = [Math.floor($index/3), $index % 3]

    try {
      var mark = this.game.currentPlayer;
      this.game.playMove(move);
      if (mark === "x") {
        $square.addClass('red-played');
      } else {
        $square.addClass('blue-played');
      }
    } catch (e) {
      if (e instanceof TTT.MoveError) {
        alert(e.msg);
      } else {
        alert(e.msg);
        throw e;
      }
    }

    this.isWon();
  };

  View.prototype.setupBoard = function () {
    var $body = $('body');
    var $ul = $('<ul class="grid group">');

    for (var i = 0; i < 9; i++) {
      var $li = $('<li class="cell">');
      $ul.append($li);
      console.log("time" + i, $li);
    }
    $body.append($ul);

  };

  View.prototype.isWon = function () {
    if (this.game.isOver()) {

      if (this.game.winner()) {
        var result = this.game.winner().toUpperCase() + " has won!";
      } else {
        var result = "NO ONE WINS!";
      }
      // gameCompletionCallback();

      var $gameOver = $('<p class="won"></p>')
      $gameOver.text(result);
      $("body").prepend($gameOver);

      $("ul").unbind("click")

    }
  };

})();
